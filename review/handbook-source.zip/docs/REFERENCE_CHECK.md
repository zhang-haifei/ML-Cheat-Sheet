# 参考入口核对

2026-10-30。当前PDF有37个外部URI注释、37个不同地址。资料入口的访问记录来自本轮及此前检查：原有35个地址沿用2026-10-29的观察，本轮补核Boyd教材官网，源码包入口使用仓库连接器核对。33个资料地址已解析，1个源码包入口经仓库核对，1个资料地址只确认重定向，2个受限或超时。此处记录实际工具观察，不作未来可达性保证，也不把可读取当作全文科学审定。

DBSCAN论文改用可读取的AAAI官方CDN。LSTM的正式DOI返回403，Stanford教材入口超时，均保留原引文。PyTorch stable是浮动别名；工具本次返回的版本信息不等于本项目安装或测试了该框架版本。

| PDF入口 | 工具观察 | 解析目标或说明 |
|---|---|---|
| [cdn.aaai.org / KDD96-037.pdf](https://cdn.aaai.org/KDD/1996/KDD96-037.pdf) | 已解析 | 旧地址工具不可读取；已替换为AAAI官方CDN，论文6页可读取 |
| [arxiv.org / 1301.3781](https://arxiv.org/abs/1301.3781) | 已解析 |  |
| [arxiv.org / 1406.1078](https://arxiv.org/abs/1406.1078) | 已解析 |  |
| [arxiv.org / 1412.6980](https://arxiv.org/abs/1412.6980) | 已解析 |  |
| [arxiv.org / 1502.01852](https://arxiv.org/abs/1502.01852) | 已解析 |  |
| [arxiv.org / 1512.03385](https://arxiv.org/abs/1512.03385) | 已解析 |  |
| [arxiv.org / 1706.03762](https://arxiv.org/abs/1706.03762) | 已解析 |  |
| [arxiv.org / 1711.05101](https://arxiv.org/abs/1711.05101) | 已解析 |  |
| [d2l.ai / 主页](https://d2l.ai/) | 已解析 |  |
| [d2l.ai / backprop.html](https://d2l.ai/chapter_multilayer-perceptrons/backprop.html) | 已解析 |  |
| [docs.pytorch.org / 主页](https://docs.pytorch.org/docs/stable/) | 重定向后已解析 | [目标](https://docs.pytorch.org/docs/2.15/)；stable为浮动入口；本次工具返回2.15文档 |
| [docs.pytorch.org / torch.nn.BCEWithLogitsLoss.html](https://docs.pytorch.org/docs/stable/generated/torch.nn.BCEWithLogitsLoss.html) | 重定向后已解析 | [目标](https://docs.pytorch.org/docs/2.15/generated/torch.nn.BCEWithLogitsLoss.html)；stable为浮动入口；本次工具返回2.15文档 |
| [docs.pytorch.org / torch.nn.CrossEntropyLoss.html](https://docs.pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html) | 重定向后已解析 | [目标](https://docs.pytorch.org/docs/2.15/generated/torch.nn.CrossEntropyLoss.html)；stable为浮动入口；本次工具返回2.15文档 |
| [docs.pytorch.org / torch.nn.Dropout.html](https://docs.pytorch.org/docs/stable/generated/torch.nn.Dropout.html) | 重定向后已解析 | [目标](https://docs.pytorch.org/docs/2.15/generated/torch.nn.Dropout.html)；stable为浮动入口；本次工具返回2.15文档 |
| [docs.pytorch.org / torch.optim.Adam.html](https://docs.pytorch.org/docs/stable/generated/torch.optim.Adam.html) | 重定向后已解析 | [目标](https://docs.pytorch.org/docs/2.15/generated/torch.optim.Adam.html)；stable为浮动入口；本次工具返回2.15文档 |
| [docs.pytorch.org / nn.init.html](https://docs.pytorch.org/docs/stable/nn.init.html) | 仅确认重定向 | [目标](https://docs.pytorch.org/docs/2.15/nn.init.html)；stable入口可读取；目标页未能由工具解析 |
| [docs.pytorch.org / transfer_learning_tutorial.html](https://docs.pytorch.org/tutorials/beginner/transfer_learning_tutorial.html) | 已解析 |  |
| [doi.org / neco.1997.9.8.1735](https://doi.org/10.1162/neco.1997.9.8.1735) | 访问受限 | 工具收到403；保留正式DOI，不据此认定链接失效 |
| [imbalanced-learn.org / 主页](https://imbalanced-learn.org/stable/) | 已解析 |  |
| [jmlr.org / bergstra12a.html](https://jmlr.org/papers/v13/bergstra12a.html) | 已解析 |  |
| [jmlr.org / srivastava14a.html](https://jmlr.org/papers/v15/srivastava14a.html) | 已解析 |  |
| [keras.io / 主页](https://keras.io/api/callbacks/early_stopping/) | 已解析 |  |
| [mml-book.github.io / 主页](https://mml-book.github.io/) | 已解析 |  |
| [nlp.stanford.edu / 主页](https://nlp.stanford.edu/IR-book/) | 待复查 | 工具两次超时；保留教材作者网站 |
| [scikit-learn.org / common_pitfalls.html](https://scikit-learn.org/stable/common_pitfalls.html) | 已解析 |  |
| [scikit-learn.org / sklearn.metrics.r2_score.html](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.r2_score.html) | 已解析 |  |
| [scikit-learn.org / sklearn.metrics.roc_auc_score.html](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.roc_auc_score.html) | 已解析 |  |
| [scikit-learn.org / user_guide.html](https://scikit-learn.org/stable/user_guide.html) | 已解析 |  |
| [www.deeplearningbook.org / 主页](https://www.deeplearningbook.org/) | 已解析 |  |
| [www.statlearning.com / 主页](https://www.statlearning.com/) | 已解析 |  |
| [web.stanford.edu / cvxbook](https://web.stanford.edu/~boyd/cvxbook/) | 已解析 | 2026-10-30补核作者教材主页，补全正文已引用的Boyd与Vandenberghe教材汇总入口 |
| [GitHub / 配套源码包](https://github.com/zhang-haifei/ML-Cheat-Sheet/blob/main/review/handbook-source.zip) | 仓库连接器核对 | 阅读说明中的配套文件入口；交付时核对main分支与源码包Git blob，不将其计作科学参考资料 |
| [zh.d2l.ai / 主页](https://zh.d2l.ai/) | 已解析 |  |
| [docs.pytorch.org / BatchNorm2d](https://docs.pytorch.org/docs/stable/generated/torch.nn.BatchNorm2d.html) | 重定向后已解析 | 工具返回2.15文档；核对统计轴、方差分母、运行统计与评估模式 |
| [docs.pytorch.org / LayerNorm](https://docs.pytorch.org/docs/stable/generated/torch.nn.LayerNorm.html) | 重定向后已解析 | 工具返回2.15文档；核对normalized_shape末尾轴与训练/评估统计 |
| [docs.pytorch.org / GRU](https://docs.pytorch.org/docs/stable/generated/torch.nn.GRU.html) | 重定向后已解析 | 工具返回2.15文档；明确对照原始写法与PyTorch重置门位置及偏置位置 |
| [scikit-learn.org / TF-IDF](https://scikit-learn.org/stable/modules/feature_extraction.html#tfidf-term-weighting) | 已解析 | 核对原始计数、平滑IDF、L2归一化与分词器边界 |

补充核对：[Cambridge第9章Linear Predictors](https://www.cambridge.org/core/books/abs/understanding-machine-learning/linear-predictors/FF366AA369F369BA571D934AF66EC412)对应2014年Shalev-Shwartz与Ben-David教材的线性预测器章节；本书的感知机继续阅读入口据此核对。AdamW、残差网络、注意力与Word2Vec等论文的arXiv入口标题/作者/年代与引文相符。

[Keras EarlyStopping文档](https://keras.io/api/callbacks/early_stopping/)明确区分停止与恢复最佳权重，当前默认restore_best_weights为False；本书要求检查恢复规则的说明与之相符。

2026-10-29复查记录：原有3个未完整解析入口中，Stanford教材主页及官方HTML/PDF入口仍超时，LSTM正式DOI仍403，nn.init仍只确认stable重定向而未解析目标。另核对Cho等2014年论文的官方arXiv HTML，确认重置门与候选状态的定义。保留正式入口，不以未核验镜像替换。

最后成书校读补齐《Convex Optimization》的汇总条目和作者提供的公开入口。原有35个地址沿用已记录的访问观察；本次不声称逐一重新访问，也不将3个工具读取受限入口视为失效。

2026-11-02补充：针对性实测使用PyTorch 2.9.0+cpu，并核对该版本的[BatchNorm2d](https://docs.pytorch.org/docs/2.9/generated/torch.nn.BatchNorm2d.html)、[LayerNorm](https://docs.pytorch.org/docs/2.9/generated/torch.nn.LayerNorm.html)与[GRU](https://docs.pytorch.org/docs/2.9/generated/torch.nn.GRU.html)官方说明。结果见TORCH_CHECKS.json；此处版本化资料用于配套验证，不新增PDF外部入口。原有3个读取受限入口沿用已记录观察。
同版本的[Conv2d](https://docs.pytorch.org/docs/2.9/generated/torch.nn.Conv2d.html)、[RNN](https://docs.pytorch.org/docs/2.9/generated/torch.nn.RNN.html)和[LSTMCell](https://docs.pytorch.org/docs/2.9/generated/torch.nn.LSTMCell.html)亦与本轮构造算例对应核对。

2026-11-03全文润色：36个科学资料地址及正式引文保持原样，沿用上述实际访问日期与观察。1个配套源码地址改为独立润色分支，与本轮PDF/源码包配套；37个URI注释及不同地址仍逐项核对。

2026-11-04合并与清理：配套源码入口统一为main分支。36个科学资料地址和正文引文未变。
